
package entidades;

import java.util.Date;


public class movimientos_financieros {
    
    private int id_movimiento;
     private int id_empresa;
      private int id_cuenta;
       private int id_categoria;
        private String tipo_movimiento;
         private String concepto;
          private double monto;
           private Date fecha_movimiento;
            private String referencia;
             private String observaciones;

    public movimientos_financieros(int id_movimiento, int id_empresa, int id_cuenta, int id_categoria, String tipo_movimiento, String concepto, double monto, Date fecha_movimiento, String referencia, String observaciones) {
        this.id_movimiento = id_movimiento;
        this.id_empresa = id_empresa;
        this.id_cuenta = id_cuenta;
        this.id_categoria = id_categoria;
        this.tipo_movimiento = tipo_movimiento;
        this.concepto = concepto;
        this.monto = monto;
        this.fecha_movimiento = fecha_movimiento;
        this.referencia = referencia;
        this.observaciones = observaciones;
    }

    public int getId_movimiento() {
        return id_movimiento;
    }

    public void setId_movimiento(int id_movimiento) {
        this.id_movimiento = id_movimiento;
    }

    public int getId_empresa() {
        return id_empresa;
    }

    public void setId_empresa(int id_empresa) {
        this.id_empresa = id_empresa;
    }

    public int getId_cuenta() {
        return id_cuenta;
    }

    public void setId_cuenta(int id_cuenta) {
        this.id_cuenta = id_cuenta;
    }

    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public String getTipo_movimiento() {
        return tipo_movimiento;
    }

    public void setTipo_movimiento(String tipo_movimiento) {
        this.tipo_movimiento = tipo_movimiento;
    }

    public String getConcepto() {
        return concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public Date getFecha_movimiento() {
        return fecha_movimiento;
    }

    public void setFecha_movimiento(Date fecha_movimiento) {
        this.fecha_movimiento = fecha_movimiento;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    @Override
    public String toString() {
        return "movimientos_financieros{" + "id_movimiento=" + id_movimiento + ", id_empresa=" + id_empresa + ", id_cuenta=" + id_cuenta + ", id_categoria=" + id_categoria + ", tipo_movimiento=" + tipo_movimiento + ", concepto=" + concepto + ", monto=" + monto + ", fecha_movimiento=" + fecha_movimiento + ", referencia=" + referencia + ", observaciones=" + observaciones + '}';
    }
    
    
    
    
    
}
