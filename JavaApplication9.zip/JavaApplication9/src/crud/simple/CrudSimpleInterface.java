/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package crud.simple;
import java.util.List;
/**
 *
 * @author prestamo
 */
public interface CrudSimpleInterface<T> {
     public List<T> listar(String texto);
     public boolean insertar(T obj);
     public boolean actualizar(T obj);
     public boolean desactivar(T obj);
     public boolean activar(int id);
     public int total();
        
    
}
