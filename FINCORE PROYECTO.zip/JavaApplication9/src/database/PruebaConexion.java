package database;

import java.sql.Connection;

public class PruebaConexion {
    public static void main(String[] args) {
        try (Connection con = Conexion.conectar()) {
            System.out.println("Conectado correctamente a FINCORE.");
        } catch (Exception ex) {
            System.err.println("No fue posible conectar: " + ex.getMessage());
        }
    }
}
