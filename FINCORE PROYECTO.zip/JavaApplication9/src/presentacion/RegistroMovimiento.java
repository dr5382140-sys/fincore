package presentacion;

import database.Conexion;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.*;

public class RegistroMovimiento extends JFrame {
    private final JTextField txtEmpresa = new JTextField("1", 18);
    private final JTextField txtCuenta = new JTextField("1", 18);
    private final JTextField txtCategoria = new JTextField("1", 18);
    private final JComboBox<String> cmbTipo = new JComboBox<>(new String[]{"INGRESO", "GASTO"});
    private final JTextField txtConcepto = new JTextField(18);
    private final JTextField txtMonto = new JTextField(18);
    private final JTextField txtFecha = new JTextField(
            LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")), 18);
    private final JTextField txtReferencia = new JTextField(18);
    private final JTextArea txtObservaciones = new JTextArea(4, 18);

    public RegistroMovimiento() {
        setTitle("FINCORE - Registrar movimiento financiero");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(570, 570);
        setLocationRelativeTo(null);
        construirFormulario();
    }

    private void construirFormulario() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;

        int fila = 0;
        agregarFila(panel, c, fila++, "ID empresa:", txtEmpresa);
        agregarFila(panel, c, fila++, "ID cuenta financiera:", txtCuenta);
        agregarFila(panel, c, fila++, "ID categoría (opcional):", txtCategoria);
        agregarFila(panel, c, fila++, "Tipo de movimiento:", cmbTipo);
        agregarFila(panel, c, fila++, "Concepto:", txtConcepto);
        agregarFila(panel, c, fila++, "Monto (ej. 150000.00):", txtMonto);
        agregarFila(panel, c, fila++, "Fecha (yyyy-MM-dd HH:mm:ss):", txtFecha);
        agregarFila(panel, c, fila++, "Referencia (opcional):", txtReferencia);

        c.gridx = 0; c.gridy = fila; c.weightx = 0;
        panel.add(new JLabel("Observaciones:"), c);
        c.gridx = 1; c.weightx = 1;
        JScrollPane scroll = new JScrollPane(txtObservaciones);
        panel.add(scroll, c);

        JButton btnGuardar = new JButton("Guardar movimiento");
        JButton btnLimpiar = new JButton("Limpiar");
        btnGuardar.addActionListener(e -> guardarMovimiento());
        btnLimpiar.addActionListener(e -> limpiar());

        JPanel botones = new JPanel();
        botones.add(btnGuardar);
        botones.add(btnLimpiar);

        JLabel nota = new JLabel("<html><small>El ID del movimiento lo genera automáticamente la base de datos.</small></html>");
        JPanel inferior = new JPanel(new BorderLayout(5, 5));
        inferior.add(nota, BorderLayout.NORTH);
        inferior.add(botones, BorderLayout.SOUTH);

        setLayout(new BorderLayout());
        add(new JLabel("  Registro de movimientos financieros", SwingConstants.CENTER), BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
        add(inferior, BorderLayout.SOUTH);
    }

    private void agregarFila(JPanel panel, GridBagConstraints c, int fila, String etiqueta, java.awt.Component campo) {
        c.gridy = fila; c.gridx = 0; c.weightx = 0;
        panel.add(new JLabel(etiqueta), c);
        c.gridx = 1; c.weightx = 1;
        panel.add(campo, c);
    }

    private void guardarMovimiento() {
        try {
            int idEmpresa = Integer.parseInt(txtEmpresa.getText().trim());
            int idCuenta = Integer.parseInt(txtCuenta.getText().trim());
            String categoriaTexto = txtCategoria.getText().trim();
            Integer idCategoria = categoriaTexto.isEmpty() ? null : Integer.valueOf(categoriaTexto);
            String tipo = (String) cmbTipo.getSelectedItem();
            String concepto = txtConcepto.getText().trim();
            BigDecimal monto = new BigDecimal(txtMonto.getText().trim().replace(",", "."));
            LocalDateTime fecha = LocalDateTime.parse(
                    txtFecha.getText().trim(),
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            if (concepto.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Escribe el concepto del movimiento.", "Dato requerido", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (monto.compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(this, "El monto debe ser mayor que cero.", "Dato inválido", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String sql = "INSERT INTO movimientos_financieros "
                    + "(id_empresa, id_cuenta, id_categoria, tipo_movimiento, concepto, monto, fecha_movimiento, referencia, observaciones) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try (Connection con = Conexion.conectar();
                 PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, idEmpresa);
                ps.setInt(2, idCuenta);
                if (idCategoria == null) ps.setNull(3, java.sql.Types.INTEGER);
                else ps.setInt(3, idCategoria);
                ps.setString(4, tipo);
                ps.setString(5, concepto);
                ps.setBigDecimal(6, monto);
                ps.setTimestamp(7, Timestamp.valueOf(fecha));
                ps.setString(8, vacioANull(txtReferencia.getText()));
                ps.setString(9, vacioANull(txtObservaciones.getText()));
                ps.executeUpdate();
            }

            JOptionPane.showMessageDialog(this, "¡Movimiento guardado correctamente en FINCORE!", "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);
            limpiar();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Revisa los ID y el monto. Los ID deben ser números enteros.", "Dato inválido", JOptionPane.ERROR_MESSAGE);
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "La fecha debe tener el formato yyyy-MM-dd HH:mm:ss. Ejemplo: 2026-11-17 18:30:00", "Fecha inválida", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "No fue posible guardar el movimiento.\n\n" + ex.getMessage()
                    + "\n\nVerifica que exista la base fincore, que los ID de empresa/cuenta/categoría correspondan entre sí y que MySQL esté iniciado.",
                    "Error de base de datos", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String vacioANull(String valor) {
        String limpio = valor == null ? "" : valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    private void limpiar() {
        txtConcepto.setText("");
        txtMonto.setText("");
        txtReferencia.setText("");
        txtObservaciones.setText("");
        txtFecha.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        txtConcepto.requestFocus();
    }
}
